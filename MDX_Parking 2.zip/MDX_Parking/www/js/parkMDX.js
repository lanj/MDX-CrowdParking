
eqfeed_callback({
"type": "FeatureCollection",
"features": [
	{"type": "Feature",
		"geometry":{ "type": "Point", "coordinates": [-0.2259573, 51.5898860 ]},
	"properties": { "street": "Church Street" , "baytype":"Charged parking Mon-Fri 9am-5pm","accessible":true}
	},
    {"type": "Feature",
		"geometry" :{"type": "Point", "coordinates": [-0.2286036 , 51.5880136 ]},
		"properties": {"street": "Edgerton Street", "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
	},
{"type": "Feature",
	"geometry" :{"type": "Point", "coordinates": [-0.2287016 , 51.5879706 ]},
	"properties": {"street": "Edgerton Street","accessible":true}
},
{"type": "Feature",
	"geometry":{ "type": "Point", "coordinates": [-0.2289265, 51.5880674 ]},
	"properties": { "street": "St Josephs Grove", "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
},
{"type": "Feature",
	"geometry":{ "type": "Point", "coordinates": [-0.2289985, 51.5880684 ]},
	"properties": { "street": "St Josephs Grove", "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
},
{"type": "Feature",
	"geometry" :{"type": "Point", "coordinates": [-0.2307985 , 51.5882007 ]},
	"properties": {"street": "St Josephs Grove" , "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
},
{"type": "Feature",
	"geometry" :{"type": "Point", "coordinates": [-0.2327136 , 51.5886297 ]},
	"properties": {"street": "St Josephs Grove", "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
},
{"type": "Feature",
	"geometry":{ "type": "Point", "coordinates": [-0.2288047, 51.5911034 ]},
	"properties": { "street": "Church End", "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
},
{"type": "Feature",
	"geometry" :{"type": "Point", "coordinates": [-0.2280006 , 51.5912005 ]},
	"properties": {"street": "Church End", "baytype":"Charged for parking Mon-Fri 9am-5pm","accessible":true}
}

]

})

